from controller import StudentController

if __name__ == "__main__":
    controller = StudentController()
    controller.show_menu()
